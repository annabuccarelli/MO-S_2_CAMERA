# MO-S_2
esercitazione corso interior design
